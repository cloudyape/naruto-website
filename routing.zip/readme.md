# Naruto - A Full Stack Development Framework using Python
Naruto is a full stack Python Development library. It really fun and Easy.
## Below are some useful commands
| Command | Action |
| ----------- | ----------- |
| naruto setup new | Setup a new Project |
| naruto n c <componentName> | To Setup a new component|
| naruto run | To start local server on 8000|
| naruto run port <portNumber> | To start local server on Custom Port|
| naruto deploy | To deploy naruto project on cloud |
