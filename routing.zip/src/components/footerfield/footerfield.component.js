
                
                
                
/***********************Write all JS above this ******************/
updateHtml()
                