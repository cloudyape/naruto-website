loadTag('headerfield');
loadTag('footerfield');  
loadTag('sidebar');                              
                               
/***********************Write all JS above this ******************/
updateHtml()                               
                               